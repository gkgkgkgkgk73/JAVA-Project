import java.io.*;
import java.util.*;

public class SortingTest
{
	public static void main(String args[])
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		try
		{
			boolean isRandom = false;	// 입력받은 배열이 난수인가 아닌가?
			int[] value;	// 입력 받을 숫자들의 배열
			String nums = br.readLine();	// 첫 줄을 입력 받음
			if (nums.charAt(0) == 'r')
			{
				// 난수일 경우
				isRandom = true;	// 난수임을 표시

				String[] nums_arg = nums.split(" ");

				int numsize = Integer.parseInt(nums_arg[1]);	// 총 갯수
				int rminimum = Integer.parseInt(nums_arg[2]);	// 최소값
				int rmaximum = Integer.parseInt(nums_arg[3]);	// 최대값

				Random rand = new Random();	// 난수 인스턴스를 생성한다.

				value = new int[numsize];	// 배열을 생성한다.
				for (int i = 0; i < value.length; i++)	// 각각의 배열에 난수를 생성하여 대입
					value[i] = rand.nextInt(rmaximum - rminimum + 1) + rminimum;
			}
			else
			{
				// 난수가 아닐 경우
				int numsize = Integer.parseInt(nums);

				value = new int[numsize];	// 배열을 생성한다.
				for (int i = 0; i < value.length; i++)	// 한줄씩 입력받아 배열원소로 대입
					value[i] = Integer.parseInt(br.readLine());
			}

			// 숫자 입력을 다 받았으므로 정렬 방법을 받아 그에 맞는 정렬을 수행한다.
			while (true)
			{
				int[] newvalue = (int[])value.clone();	// 원래 값의 보호를 위해 복사본을 생성한다.

				String command = br.readLine();

				long t = System.currentTimeMillis();
				switch (command.charAt(0))
				{
					case 'B':	// Bubble Sort
						newvalue = DoBubbleSort(newvalue);
						break;
					case 'I':	// Insertion Sort
						newvalue = DoInsertionSort(newvalue);
						break;
					case 'H':	// Heap Sort
						newvalue = DoHeapSort(newvalue);
						break;
					case 'M':	// Merge Sort
						newvalue = DoMergeSort(newvalue);
						break;
					case 'Q':	// Quick Sort
						newvalue = DoQuickSort(newvalue);
						break;
					case 'R':	// Radix Sort
						newvalue = DoRadixSort(newvalue);
						break;
					case 'X':
						return;	// 프로그램을 종료한다.
					default:
						throw new IOException("잘못된 정렬 방법을 입력했습니다.");
				}
				if (isRandom)
				{
					// 난수일 경우 수행시간을 출력한다.
					System.out.println((System.currentTimeMillis() - t) + " ms");
				}
				else
				{
					// 난수가 아닐 경우 정렬된 결과값을 출력한다.
					for (int i = 0; i < newvalue.length; i++)
					{
						System.out.println(newvalue[i]);
					}
				}

			}
		}
		catch (IOException e)
		{
			System.out.println("입력이 잘못되었습니다. 오류 : " + e.toString());
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static int[] DoBubbleSort(int[] value)
	{
		int temp=0;
		int[] res = new int[value.length];
		for(int i=0;i<value.length;i++){
			res[i]=value[i];
		}
		// TODO : Bubble Sort 를 구현하라.
		for(int i=res.length-1;i>=0;i--){
			for(int j=0;j<i;j++){
				if(res[j]>res[j+1]){
					temp=res[j];
					res[j]=res[j+1];
					res[j+1]=temp;
				}
			}
		}
		return res;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static int[] DoInsertionSort(int[] value)
	{
		// TODO : Insertion Sort 를 구현하라.
		int[] res = new int[value.length];
		res[0]=value[0];
		for(int i=1;i<res.length;i++){
			int j=i-1;
			while(j>=0&&value[i]<res[j]){
			res[j+1]=res[j];
			j--; }
			res[j+1]=value[i];
		}
		return res;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static int[] DoHeapSort(int[] value)
	{
		int numItem = value.length;
		int[] res = new int[value.length];
		buildHeap(value);
		for(int i=value.length-1;i>=0;i--){
			res[i]=deleteMax(value,numItem);
			numItem--;
		}
		return res;
	}

	private static int deleteMax(int[] value,int numItems){
		int max = value[0];
		if(numItems!=0){
			value[0] = value[numItems-1];
			percolateDown(value,0, numItems);
		}
		return max;
	}

	private static void buildHeap(int[] value){
		if (value.length>=2){
			for(int i=(value.length-2)/2;i>=0;i--){
				percolateDown(value, i, value.length);
			}
		}

	}

	private static void percolateDown(int[] value, int i, int numItem){
		int child = 2*i+1;
		int rightchild = 2*i+2;
		if(child <= numItem-1){
			if(rightchild <= numItem-1&&value[child]<value[rightchild]){
				child = rightchild;
			}
			if(value[i]<value[child]){
				int temp = value[i];
				value[i]=value[child];
				value[child]=temp;
				percolateDown(value, child, numItem);
			}
		}

	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static int[] DoMergeSort(int[] value){

		return mergeSort(value, 0, value.length-1);
	}
	private static int[] mergeSort(int[] value, int p, int r)
	{
		int q;
		// TODO : Merge Sort 를 구현하라.
		if(p<r){
			q=(p+r)/2;
			mergeSort(value,p,q);
			mergeSort(value,q+1,r);
			merge(value,p,q,r);
		}
		return value;
	}

	private static void merge(int[] value, int p, int q, int r){
		int[] res = new int[value.length];
		int i=p;
		int j=q+1;
		int t=0;
		while(i<=q&&j<=r){
			if(value[i]<=value[j]){
				res[t++]=value[i++];
			}else{
				res[t++]=value[j++];
			}
		}
		while(i<=q){
			res[t++]=value[i++];
		}
		while(j<=r){
			res[t++]=value[j++];
		}
		i=p;t=0;
		while(i<=r){
			value[i++]=res[t++];
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static int[] DoQuickSort(int[] value)
	{
		return quickSort(value,0,value.length-1);
	}

	private static int[] quickSort(int[] value, int p, int r){
		int q;
		if(p<r){
			q=partition(value,p,r);
			quickSort(value,p,q-1);
			quickSort(value,q+1,r);
		}
		return value;
	}

	private static int partition(int[] value, int p, int r){
		int pivot = value[r];
		int i=p-1;
		int temp;
		for(int j=p;j<r;j++){
			if(value[j]<=pivot){
				temp = value[++i];
				value[i]=value[j];
				value[j]=temp;
			}
		}
		temp = value[i+1];
		value[i+1]=value[r];
		value[r]=temp;
		return i+1;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	private static int[] DoRadixSort(int[] value)
	{
		int[] minus = new int[value.length];
		int lastElementIndexOfMinus = 0;
		int[] plus = new int[value.length];
		int lastElementIndexOfPlus = 0;
		int[] temp = new int[value.length];
		for(int k=0;k<value.length;k++){
			temp[k]=value[k];
		}
		for(int i=0;i<11;i++){
			int[] numZero = new int[value.length];
			int lastElementOfNumZero = 0;
			int[] numOne = new int[value.length];
			int lastElementOfNumOne = 0;
			int[] numTwo = new int[value.length];
			int lastElementOfNumTwo = 0;
			int[] numThree= new int[value.length];
			int lastElementOfNumThree = 0;
			int[] numFour = new int[value.length];
			int lastElementOfNumFour = 0;
			int[] numFive = new int[value.length];
			int lastElementOfNumFive = 0;
			int[] numSix = new int[value.length];
			int lastElementOfNumSix = 0;
			int[] numSeven = new int[value.length];
			int lastElementOfNumSeven = 0;
			int[] numEight = new int[value.length];
			int lastElementOfNumEight = 0;
			int[] numNine = new int[value.length];
			int lastElementOfNumNine = 0;
			if(i<9){
				int divisor = (int) Math.pow(10,i);
				for(int k=0;k<temp.length;k++){
					if(temp[k]>=0){
						switch ((temp[k]%(divisor*10) -temp[k]%divisor)/divisor) {
							case 0:
								numZero[lastElementOfNumZero++] = temp[k];
								break;
							case 1:
								numOne[lastElementOfNumOne++] = temp[k];
								break;
							case 2:
								numTwo[lastElementOfNumTwo++] = temp[k];
								break;
							case 3:
								numThree[lastElementOfNumThree++] = temp[k];
								break;
							case 4:
								numFour[lastElementOfNumFour++] =temp[k];
								break;
							case 5:
								numFive[lastElementOfNumFive++] =temp[k];
								break;
							case 6:
								numSix[lastElementOfNumSix++] = temp[k];
								break;
							case 7:
								numSeven[lastElementOfNumSeven++] = temp[k];
								break;
							case 8:
								numEight[lastElementOfNumEight++] = temp[k];
								break;
							case 9:
								numNine[lastElementOfNumNine++] = temp[k];
								break;
						}
					}else{
						switch (((temp[k]%(divisor*10) - temp[k]%divisor)/divisor)) {
							case 0:
								numZero[lastElementOfNumZero++] = temp[k];
								break;
							case -1:
								numOne[lastElementOfNumOne++] = temp[k];
								break;
							case -2:
								numTwo[lastElementOfNumTwo++] = temp[k];
								break;
							case -3:
								numThree[lastElementOfNumThree++] = temp[k];
								break;
							case -4:
								numFour[lastElementOfNumFour++] =temp[k];
								break;
							case -5:
								numFive[lastElementOfNumFive++] =temp[k];
								break;
							case -6:
								numSix[lastElementOfNumSix++] = temp[k];
								break;
							case -7:
								numSeven[lastElementOfNumSeven++] =temp[k];
								break;
							case -8:
								numEight[lastElementOfNumEight++] = temp[k];
								break;
							case -9:
								numNine[lastElementOfNumNine++] = temp[k];
								break;
						}
					}
				}
				for(int j=0;j<lastElementOfNumZero;j++){
					temp[j]=numZero[j];
				}
				for(int j=0;j<lastElementOfNumOne;j++){
					temp[j+lastElementOfNumZero]=numOne[j];
				}
				for(int j=0;j<lastElementOfNumTwo;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne]=numTwo[j];
				}
				for(int j=0;j<lastElementOfNumThree;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo]=numThree[j];
				}
				for(int j=0;j<lastElementOfNumFour;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree]=numFour[j];
				}
				for(int j=0;j<lastElementOfNumFive;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour]=numFive[j];
				}
				for(int j=0;j<lastElementOfNumSix;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour+lastElementOfNumFive]=numSix[j];
				}
				for(int j=0;j<lastElementOfNumSeven;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour+lastElementOfNumFive+lastElementOfNumSix]=numSeven[j];
				}
				for(int j=0;j<lastElementOfNumEight;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour+lastElementOfNumFive+ lastElementOfNumSix+lastElementOfNumSeven]=numEight[j];
				}
				for(int j=0;j<lastElementOfNumNine;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour+lastElementOfNumFive+ lastElementOfNumSix+lastElementOfNumSeven+lastElementOfNumEight]=numNine[j];
				} }
			else if(i==10){
				for(int k=0;k<temp.length;k++){
					if(temp[k]>=0){
						switch ((temp[k]/1000000000)) {
							case 0:
								numZero[lastElementOfNumZero++] = temp[k];
								break;
							case 1:
								numOne[lastElementOfNumOne++] = temp[k];
								break;
							case 2:
								numTwo[lastElementOfNumTwo++] = temp[k];
								break;
							case 3:
								numThree[lastElementOfNumThree++] = temp[k];
								break;
							case 4:
								numFour[lastElementOfNumFour++] =temp[k];
								break;
							case 5:
								numFive[lastElementOfNumFive++] =temp[k];
								break;
							case 6:
								numSix[lastElementOfNumSix++] = temp[k];
								break;
							case 7:
								numSeven[lastElementOfNumSeven++] = temp[k];
								break;
							case 8:
								numEight[lastElementOfNumEight++] = temp[k];
								break;
							case 9:
								numNine[lastElementOfNumNine++] = temp[k];
								break;
						}
					}else{
						switch ((temp[k]/1000000000)) {
							case 0:
								numZero[lastElementOfNumZero++] = temp[k];
								break;
							case -1:
								numOne[lastElementOfNumOne++] = temp[k];
								break;
							case -2:
								numTwo[lastElementOfNumTwo++] = temp[k];
								break;
							case -3:
								numThree[lastElementOfNumThree++] = temp[k];
								break;
							case -4:
								numFour[lastElementOfNumFour++] =temp[k];
								break;
							case -5:
								numFive[lastElementOfNumFive++] =temp[k];
								break;
							case -6:
								numSix[lastElementOfNumSix++] = temp[k];
								break;
							case -7:
								numSeven[lastElementOfNumSeven++] =temp[k];
								break;
							case -8:
								numEight[lastElementOfNumEight++] = temp[k];
								break;
							case -9:
								numNine[lastElementOfNumNine++] = temp[k];
								break;
						}
					}
				}
				for(int j=0;j<lastElementOfNumZero;j++){
					temp[j]=numZero[j];
				}
				for(int j=0;j<lastElementOfNumOne;j++){
					temp[j+lastElementOfNumZero]=numOne[j];
				}
				for(int j=0;j<lastElementOfNumTwo;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne]=numTwo[j];
				}
				for(int j=0;j<lastElementOfNumThree;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo]=numThree[j];
				}
				for(int j=0;j<lastElementOfNumFour;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree]=numFour[j];
				}
				for(int j=0;j<lastElementOfNumFive;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour]=numFive[j];
				}
				for(int j=0;j<lastElementOfNumSix;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour+lastElementOfNumFive]=numSix[j];
				}
				for(int j=0;j<lastElementOfNumSeven;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour+lastElementOfNumFive+lastElementOfNumSix]=numSeven[j];
				}
				for(int j=0;j<lastElementOfNumEight;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour+lastElementOfNumFive+ lastElementOfNumSix+lastElementOfNumSeven]=numEight[j];
				}
				for(int j=0;j<lastElementOfNumNine;j++){
					temp[j+lastElementOfNumZero+lastElementOfNumOne+lastElementOfNumTwo+lastElementOfNumThree+lastElementOfNumFour+lastElementOfNumFive+ lastElementOfNumSix+lastElementOfNumSeven+lastElementOfNumEight]=numNine[j];
				}
			}
		}
		for(int k=0;k<temp.length;k++){
			if(temp[k]<0){
				minus[lastElementIndexOfMinus++]=temp[k];
			}else{
				plus[lastElementIndexOfPlus++]=temp[k];
			}
		}
		for(int k=lastElementIndexOfMinus;k>0;k--){
			temp[k-1]=minus[lastElementIndexOfMinus-k];
		}
		for(int k=0;k<lastElementIndexOfPlus;k++){
			temp[k+lastElementIndexOfMinus]=plus[k];
		}
		return temp;
	}
}
